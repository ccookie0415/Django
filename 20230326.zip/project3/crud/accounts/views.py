from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from django.contrib.auth import update_session_auth_hash
from django.views.decorators.http import require_GET
from .forms import CustomChangeForm, CustomCreationForm

# Create your views here.

def login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            auth_login(request, form.get_user())
            return redirect('articles:index')
        
    else:
        form = AuthenticationForm()

def logout(request):
    auth_logout(request)
    
def signup(request):
    if request.method =="POST":
        form = CustomCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            return redirect
        
def delete(request):
    request.user.delete()
    auth_logout(request)
    
def update(request):
    if request.method =='POST':
        form = CustomChangeForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()

def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)
            return redirect('articles:index')
            