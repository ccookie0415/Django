from django import forms
from .models import Movie
from django.forms.widgets import NumberInput

class MovieForm(forms.ModelForm):
    
    release_date = forms.DateTimeField(
        widget=NumberInput(
        attrs={
        'type':'date'
        }
        )
    )

    GENRE_A = '코미디'
    GENRE_B = '공포'
    GENRE_C = '로맨스'
    GENRES_CHOICES  = [
        (GENRE_A, '코미디'),
        (GENRE_B, '공포'),
        (GENRE_C, '로맨스'),
    ]
    genre = forms.ChoiceField(widget=forms.Select, choices=GENRES_CHOICES)

    score = forms.FloatField(
        widget = forms.NumberInput(
            attrs = {
                'class' : 'my-content form-control',
                'step' : 0.5,
                'max' : 5,
                'min' : 0,
            }
        )
    )

    class Meta:
        model = Movie
        fields = '__all__'
