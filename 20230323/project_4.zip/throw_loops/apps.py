from django.apps import AppConfig


class ThrowLoopsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'throw_loops'
